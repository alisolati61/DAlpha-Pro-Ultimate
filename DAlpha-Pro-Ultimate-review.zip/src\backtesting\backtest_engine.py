from __future__ import annotations

from dataclasses import dataclass
from typing import List

from src.ai.performance_tracker import (
    PerformanceTracker,
    TradePerformance,
)


@dataclass(slots=True)
class BacktestResult:
    """
    Result produced by the Backtest Engine.
    """

    total_trades: int
    wins: int
    losses: int
    win_rate: float

    total_profit: float
    final_balance: float


class BacktestEngine:
    """
    Production Backtest Engine.

    Responsibilities
    ----------------
    - Evaluate historical trades
    - Feed PerformanceTracker
    - Produce statistics

    Future
    -------
    - Walk Forward
    - Portfolio Backtest
    - Monte Carlo
    - Parameter Optimization
    """

    def __init__(
        self,
        initial_balance: float = 10_000.0,
    ) -> None:

        self.initial_balance = float(initial_balance)

        self.balance = float(initial_balance)

        self.performance = PerformanceTracker()

    # --------------------------------------------------

    def reset(self) -> None:

        self.balance = float(self.initial_balance)

        self.performance.clear()

    # --------------------------------------------------

    def evaluate(
        self,
        trades: List[TradePerformance],
    ) -> BacktestResult:

        self.reset()

        for trade in trades:

            self.performance.add(trade)

            self.balance += float(trade.pnl)

        return BacktestResult(
            total_trades=int(self.performance.trades),
            wins=int(self.performance.wins),
            losses=int(self.performance.losses),
            win_rate=float(self.performance.win_rate),
            total_profit=float(self.performance.total_profit),
            final_balance=float(round(self.balance, 2)),
        )

    # --------------------------------------------------

    @property
    def equity(self) -> float:

        return float(round(self.balance, 2))

    # --------------------------------------------------

    def summary(self) -> dict:

        return {
            "balance": float(self.balance),
            "statistics": self.performance.summary(),
        }