from src.ai.performance_tracker import TradePerformance
from src.backtesting.backtest_engine import (
    BacktestEngine,
    BacktestResult,
)


def make_trade(
    pnl: float,
    win: bool,
) -> TradePerformance:

    return TradePerformance(
        strategy="SMC",
        symbol="BTCUSDT",
        timeframe="1h",
        pnl=pnl,
        risk_reward=2.0,
        win=win,
        confidence=80.0,
        duration_minutes=30,
    )


def test_empty_backtest():

    engine = BacktestEngine()

    result = engine.evaluate([])

    assert isinstance(result, BacktestResult)

    assert result.total_trades == 0
    assert result.wins == 0
    assert result.losses == 0
    assert result.win_rate == 0.0
    assert result.total_profit == 0.0
    assert result.final_balance == 10000.0


def test_single_winning_trade():

    engine = BacktestEngine()

    result = engine.evaluate(
        [
            make_trade(
                pnl=150.0,
                win=True,
            )
        ]
    )

    assert result.total_trades == 1
    assert result.wins == 1
    assert result.losses == 0
    assert result.win_rate == 100.0
    assert result.total_profit == 150.0
    assert result.final_balance == 10150.0


def test_multiple_trades():

    engine = BacktestEngine()

    trades = [
        make_trade(100.0, True),
        make_trade(-40.0, False),
        make_trade(60.0, True),
        make_trade(-20.0, False),
    ]

    result = engine.evaluate(trades)

    assert result.total_trades == 4
    assert result.wins == 2
    assert result.losses == 2
    assert result.win_rate == 50.0
    assert result.total_profit == 100.0
    assert result.final_balance == 10100.0


def test_reset():

    engine = BacktestEngine()

    engine.evaluate(
        [
            make_trade(
                pnl=100.0,
                win=True,
            )
        ]
    )

    engine.reset()

    assert engine.balance == 10000.0
    assert engine.performance.trades == 0


def test_result_types():

    engine = BacktestEngine()

    result = engine.evaluate([])

    assert isinstance(result.total_trades, int)
    assert isinstance(result.wins, int)
    assert isinstance(result.losses, int)
    assert isinstance(result.win_rate, float)
    assert isinstance(result.total_profit, float)
    assert isinstance(result.final_balance, float)